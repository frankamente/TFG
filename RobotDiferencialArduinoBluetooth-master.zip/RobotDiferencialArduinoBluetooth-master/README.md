# ProyectoAmpliacionRobotica
En la carpeta ProgramaCompleto está el código Arduino y las funciones completas para el perfecto funcionamiento del robot.
El kit del robot puede comprarse aquí por ejemplo: http://www.ebay.co.uk/itm/4WD-Robot-Smart-Car-Chassis-Kit-Arduino-Uno-Driver-L298-HC-SR04-Breadboard-/281480493216